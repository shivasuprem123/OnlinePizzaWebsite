﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlinePizzaApplication.Models
{
    public class category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
      
    }
}
